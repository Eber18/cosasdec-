//mi primer programa en c++
#include <iostream>
int main(){
    x="Esto es una cadena";
    std::cout<<"Hola mundo!"<<endl;
    system("PAUSE");
    }
