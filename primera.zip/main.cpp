//mi primer programa en c++
#include <iostream>
#define PI 3.1416 //global
using namespace std;
int main()
{
    cout<<"Hola Mundo!\n\a";
    system("PAUSE");
    return EXIT_SUCCESS;
}
// const double pi=3.1416 esta es local
// \" o \�
// &= es una concatenacion
//^= es potencia
//++a primero lo usa y luego incrementa
